using System;
using System.Collections.Generic;

namespace VOnline.VBuy.Persistence.Entity
{    
    public class ProductCategoryMapping
    {
        public int Id { get; set; }
        public int Product { get; set; }
        public int Category { get; set; }
        public bool IsFeaturedProduct { get; set; }
        public int DisplayOrder { get; set; }
    
        public virtual Category CategoryMap { get; set; }
        public virtual Product ProductMap { get; set; }
    }
}
