using System;
using System.Collections.Generic;

namespace VOnline.VBuy.Persistence.Entity
{   
    public class Picture
    {
        public Picture()
        {
            this.Categories = new HashSet<Category>();
            this.Manufacturers = new HashSet<Manufacturer>();
            this.ProductPictureMappings = new HashSet<ProductPictureMapping>();
        }
    
        public int Id { get; set; }
        public byte[] PictureBinary { get; set; }
        public string MimeType { get; set; }
        public string SeoFilename { get; set; }
        public bool IsNew { get; set; }
    
        public virtual ICollection<Category> Categories { get; set; }
        public virtual ICollection<Manufacturer> Manufacturers { get; set; }
        public virtual ICollection<ProductPictureMapping> ProductPictureMappings { get; set; }
    }
}
