using System;
using System.Collections.Generic;

namespace VOnline.VBuy.Persistence.Entity
{   
    public class PermissionRecordMapping
    {
        public int PermissionRecord { get; set; }
        public int CustomerRole { get; set; }
    
    }
}
