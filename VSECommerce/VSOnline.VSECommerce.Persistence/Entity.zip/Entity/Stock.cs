using System;
using System.Collections.Generic;

namespace VOnline.VBuy.Persistence.Entity
{
   public class Stock
    {
        public int StockId { get; set; }
        public int Product { get; set; }
        public int Seller { get; set; }
        public int StockQuantity { get; set; }
        public bool DisplayStockAvailability { get; set; }
        public bool DisplayStockQuantity { get; set; }
        public int MinStockQuantity { get; set; }
        public int LowStockActivityId { get; set; }
        public int NotifyAdminForQuantityBelow { get; set; }
        public int BackorderModeId { get; set; }
        public bool AllowBackInStockSubscriptions { get; set; }
        public int OrderMinimumQuantity { get; set; }
        public int OrderMaximumQuantity { get; set; }
        public string AllowedQuantities { get; set; }
    
        public virtual Product ProductMap { get; set; }
        public virtual Seller SellerMap { get; set; }
    }
}
