﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace VOnline.VBuy.Persistence.Entity
{
    public class UserWishlist
    {
        [Key]
        public int Id { get; set; }
        public int User { get; set; }
        public int Product { get; set; }
        public System.DateTime CreatedOnUtc { get; set; }
        [ForeignKey("Product")]
        public virtual Product ProductDetails { get; set; }
        [ForeignKey("User")]
        public virtual User UserDetails { get; set; }
    }
}
