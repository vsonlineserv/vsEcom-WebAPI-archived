using System;
using System.Collections.Generic;

namespace VOnline.VBuy.Persistence.Entity
{    
    public class Country
    {
        public Country()
        {
            this.BuyerAddresses = new HashSet<BuyerAddress>();
            this.SellerAddresses = new HashSet<SellerBranch>();
        }
    
        public int CountryId { get; set; }
        public string Name { get; set; }
        public bool AllowsBilling { get; set; }
        public bool AllowsShipping { get; set; }
        public string TwoLetterIsoCode { get; set; }
        public string ThreeLetterIsoCode { get; set; }
        public int NumericIsoCode { get; set; }
        public bool SubjectToVat { get; set; }
        public bool Published { get; set; }
        public int DisplayOrder { get; set; }
    
        public virtual ICollection<BuyerAddress> BuyerAddresses { get; set; }
        public virtual ICollection<SellerBranch> SellerAddresses { get; set; }
    }
}
