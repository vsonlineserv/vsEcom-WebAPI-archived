using System;
using System.Collections.Generic;

namespace VOnline.VBuy.Persistence.Entity
{   
    public class ExternalAuthenticationRecord
    {
        public int AuthId { get; set; }
        public int User { get; set; }
        public string Email { get; set; }
        public string ExternalIdentifier { get; set; }
        public string ExternalDisplayIdentifier { get; set; }
        public string OAuthToken { get; set; }
        public string OAuthAccessToken { get; set; }
        public string ProviderSystemName { get; set; }
    
        public virtual User UserMap { get; set; }
    }
}
