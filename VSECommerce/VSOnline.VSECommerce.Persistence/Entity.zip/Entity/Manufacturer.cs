using System;
using System.Collections.Generic;

namespace VOnline.VBuy.Persistence.Entity
{   
    public class Manufacturer
    {       
        public Manufacturer()
        {
            this.ProductCollection = new HashSet<Product>();
        }
        public int ManufacturerId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string MetaKeywords { get; set; }
        public string MetaDescription { get; set; }
        public string MetaTitle { get; set; }       
        public bool? LimitedToStores { get; set; }
        public bool? Deleted { get; set; }
        public int? DisplayOrder { get; set; }
        public Nullable<System.DateTime> CreatedOnUtc { get; set; }
        public Nullable<System.DateTime> UpdatedOnUtc { get; set; }

        public virtual ICollection<Product> ProductCollection { get; set; }
    }
}
