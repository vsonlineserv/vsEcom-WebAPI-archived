﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VOnline.VBuy.Persistence.Entity
{
    public class Area
    {
        public string City { get; set; }
        public string AreaName { get; set; }
        public string Latitide { get; set; }
        public string Longitude { get; set; }
    }
}
