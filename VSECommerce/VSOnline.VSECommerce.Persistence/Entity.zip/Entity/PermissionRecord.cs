using System;
using System.Collections.Generic;

namespace VOnline.VBuy.Persistence.Entity
{   
    public class PermissionRecord
    {         
        public int Id { get; set; }
        public string Name { get; set; }
        public string SystemName { get; set; }
        public string Category { get; set; }
    
      }
}
